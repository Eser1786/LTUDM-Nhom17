package com.tkb.frontend.user.net;

import com.tkb.frontend.user.model.Types;
import com.tkb.frontend.user.model.Types.Course;
import com.tkb.frontend.user.model.Types.JobStatus;
import com.tkb.frontend.user.model.Types.PlanDetail;
import com.tkb.frontend.user.model.Types.PlanRequest;
import com.tkb.frontend.user.model.Types.SavedPlan;
import com.tkb.frontend.user.model.Types.Semester;

import java.util.List;
/**
 * Giao thuc goi server. Frontend su dung TcpTkbClient de ket noi backend thuc.
 * Moi lenh deu nem ApiException khi that bai de lop UI doi thanh thong bao than thien.
 */
public interface TkbClient {

    /** Dang nhap tai khoan nguoi dung (bat buoc truoc cac lenh USER). */
    void login(String username, String password) throws ApiException;

    /** Dang xuat (tuy chon). */
    void logout() throws ApiException;

    /** STUDENT_INFO - thong tin sinh vien hien tai (dang nhap). */
    String getUsername();
    String getRole();

    /** LIST_SEMESTERS */
    List<Semester> listSemesters() throws ApiException;

    /** LIST_COURSES - hoc phan co nhom lop dang hoat dong trong hoc ky. */
    List<Course> listCourses(String maHocKy) throws ApiException;

    /** Cac nhom lop cua mot hoc phan trong hoc ky, dung cho trang nhom lop hoc phan. */
    List<Types.SectionSlot> listSections(String maHocKy, String maMh) throws ApiException;

    /** Tat ca nhom lop dang hoat dong trong hoc ky (nhom lop theo hoc phan). */
    List<Types.SectionSlot> listAllSections(String maHocKy) throws ApiException;

    /** SUBMIT_REQUEST - tra ve jobId. Nhung hoc phan khong mo se nem COURSE_NOT_OPEN. */
    String submit(PlanRequest request) throws ApiException;

    /** JOB_PROGRESS */
    JobStatus jobStatus(String jobId) throws ApiException;

    /** CANCEL_JOB */
    void cancel(String jobId) throws ApiException;

    /** LIST_PLANS - loc theo hoc ky, null nghia la tat ca. */
    List<SavedPlan> listPlans(String maHocKy) throws ApiException;

    /** GET_PLAN */
    PlanDetail getPlan(long planId) throws ApiException;

    /** SAVE_PLAN - chi gui sectionIds; nem NAME_TAKEN neu trung ten. */
    long savePlan(String maHocKy, String ten, List<Integer> sectionIds) throws ApiException;

    /** DELETE_PLAN */
    void deletePlan(long planId) throws ApiException;

    /** RENAME_PLAN - nem NAME_TAKEN neu ten da duoc dung. */
    void renamePlan(long planId, String tenMoi) throws ApiException;

    
    // === 7a. Thêm vào interface TkbClient.java ===
    /** Yêu cầu Server sinh mã OTP đổi mật khẩu. */
    String requestPasswordOtp(String username) throws ApiException;

    /** Xác thực OTP và cập nhật mật khẩu mới. */
    void resetPasswordWithOtp(String username, String otp, String newPassword) throws ApiException;
}
